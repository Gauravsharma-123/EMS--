﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EMSProject.Models
{
    public class Users
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage = "Please Enter your Firstname")]
        public string FirstName { get; set; }
        [Required(ErrorMessage = "Please Enter your Lastname")]

        public string LastName { get; set; }
        [Required(ErrorMessage ="Please Enter your Email")]

        public string Email { get; set; }
        [DataType(DataType.Password)]
        [Required(ErrorMessage = "Please Enter your Password")]

        public string Password { get; set; }
        [Required(ErrorMessage = "Please select your Image")]

        public string Image { get; set; }
        public bool IsVerified { get; set; }
        public bool IsActive { get; set; }
    }
}
