﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EMSProject.Models.ViewModel
{
    public class ResetPasswordmodel
    {
        [Required (ErrorMessage ="Enter your New Password", AllowEmptyStrings=false)]
        [DataType(DataType.Password)]
        public string NewPassword { get; set; }
        [Compare("NewPassword", ErrorMessage ="Password does not matched")]
        [DataType(DataType.Password)]
        public string ConfirmPassword { get; set; }
    }
}
