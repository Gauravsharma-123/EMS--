﻿using System;

namespace EMSProject.Models
{
    internal class ErrorMessageAttribute : Attribute
    {
    }
}