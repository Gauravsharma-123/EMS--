﻿using EMSProject.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace EMSProject.Controllers
{
    [Authorize]
    public class EmployeeController : Controller
    {
        public EMSDBContext dbContext;

        public IHostingEnvironment Environment { get; }

        public EmployeeController(EMSDBContext context, IHostingEnvironment environment)
        {
            dbContext = context;
            Environment = environment;

        }

        // show all data in our screen
        public IActionResult Index()
        {
            var emps = dbContext.Employees.ToList();
            ViewBag.emp = emps;
            return View();
        }
        //create section with bydefault httpget method
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]   //post method for storing data frm user
        public IActionResult Create(Employees employee)
        {
//for image storimg
            var files = Request.Form.Files;
            string dbPath = string.Empty;
            if (files.Count > 0)
            {
                string path = Environment.WebRootPath;
                string fullpath = Path.Combine(path, "images", files[0].FileName);
                dbPath = "images/" + files[0].FileName;
                FileStream stream = new FileStream(fullpath, FileMode.Create);
                files[0].CopyTo(stream);
            }
            employee.Image = dbPath;
            dbContext.Employees.Add(employee);
            int a = dbContext.SaveChanges();
            if (a > 0)
            {
                TempData["InsertedMessage"] = "<script>alert('👍...Data Inserted...👍')</script>";
                ModelState.Clear();
            }
            else
            {
                TempData["InsertedMessage"] = "<script>alert('!...Data not Inserted...!')</script>";

            }
            return RedirectToAction("Create");

        }
        //Edit Section
        public IActionResult Edit(int id)
        {
            var row = dbContext.Employees.Where(model => model.Id == id).FirstOrDefault();
            TempData["rows"] = row;
            return View();
        }
        [HttpPost]//with post method for storing data
        public IActionResult Edit(Employees s)
        {
            dbContext.Entry(s).State = EntityState.Modified;
            int b = dbContext.SaveChanges();
            if (b > 0)
            {
                TempData["UpdateMessage"] = "<script>alert('Data Updated.....')</script>";
                ModelState.Clear();
                return RedirectToAction("Index");
            }
            else
            {
                ViewBag.UpdateMessage = "<script>alert('Data Not Updated.....')</script>";
            }

            return View();
        }
        public IActionResult Delete(int id)
        {
            if (id > 0)
            {
                var strow = dbContext.Employees.Where(model => model.Id == id).FirstOrDefault();
                if (strow != null)
                {
                    dbContext.Entry(strow).State = EntityState.Deleted;
                    int a = dbContext.SaveChanges();
                    if (a > 0)
                    {
                        TempData["DeleteMessage"] = "<script>alert('Data is Deleted.....')</script>";
                    }
                    else
                    {
                        TempData["DeleteMessage"] = "<script>alert('Data is Deleted.....')</script>";
                    }
                }
            }
            return RedirectToAction("Index");
        }

    }
}
